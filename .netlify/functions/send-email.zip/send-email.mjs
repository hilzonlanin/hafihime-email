
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// lib/clients.mts
import crypto from "node:crypto";
function hashToken(token) {
  return crypto.createHash("sha256").update(token).digest("hex");
}
var cache = null;
var CACHE_MS = 3e4;
function parseClients(raw) {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (c) => typeof c?.id === "string" && typeof c?.tokenHash === "string" && typeof c?.brandName === "string" && typeof c?.fromAddress === "string"
    ).map((c) => ({
      id: c.id,
      tokenHash: c.tokenHash,
      brandName: c.brandName,
      fromAddress: c.fromAddress,
      ownerAddress: c.ownerAddress,
      replyToAddress: c.replyToAddress
    }));
  } catch {
    return [];
  }
}
function getClients() {
  if (cache && Date.now() - cache.at < CACHE_MS) return cache.clients;
  const clients = parseClients(process.env.CLIENTS);
  cache = { at: Date.now(), clients };
  return clients;
}
function authenticate(header) {
  if (!header) return null;
  const match = /^Bearer\s+(.+)$/i.exec(header.trim());
  if (!match) return null;
  const provided = hashToken(match[1]);
  const clients = getClients();
  let found = null;
  for (const client of clients) {
    const a = Buffer.from(provided);
    const b = Buffer.from(client.tokenHash);
    if (a.length === b.length && crypto.timingSafeEqual(a, b)) found = client;
  }
  return found;
}

// lib/validate.mts
var EMAIL_RE = /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/;
var MAX_RECIPIENTS = 50;
var MAX_SUBJECT = 200;
var MAX_BODY = 256 * 1024;
function validEmail(value) {
  return typeof value === "string" && value.length <= 254 && EMAIL_RE.test(value);
}
function validateRequest(body) {
  if (!body || typeof body !== "object") return { ok: false, error: "invalid_body" };
  const b = body;
  const toRaw = b.to;
  const to = Array.isArray(toRaw) ? toRaw : [toRaw];
  if (to.length < 1 || to.length > MAX_RECIPIENTS || !to.every(validEmail)) {
    return { ok: false, error: "invalid_recipient" };
  }
  if (typeof b.subject !== "string" || !b.subject.trim() || b.subject.length > MAX_SUBJECT) {
    return { ok: false, error: "invalid_subject" };
  }
  const html = typeof b.html === "string" ? b.html : void 0;
  const text = typeof b.text === "string" ? b.text : void 0;
  if ((!html || !html.trim()) && (!text || !text.trim())) {
    return { ok: false, error: "empty_body" };
  }
  if (html && html.length > MAX_BODY || text && text.length > MAX_BODY) {
    return { ok: false, error: "body_too_large" };
  }
  if (b.replyTo !== void 0 && !validEmail(b.replyTo)) {
    return { ok: false, error: "invalid_reply_to" };
  }
  return {
    ok: true,
    value: {
      to: Array.isArray(toRaw) ? toRaw : to[0],
      subject: b.subject,
      html,
      text,
      replyTo: typeof b.replyTo === "string" ? b.replyTo : void 0
    }
  };
}

// lib/resend.mts
async function sendViaResend(client, req, idempotencyKey) {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.error("[mail] RESEND_API_KEY is not set \u2014 email skipped");
    return { ok: false, error: "not_configured" };
  }
  const apiBase = (process.env.RESEND_API_URL || "https://api.resend.com").replace(/\/+$/, "");
  const from = `${client.brandName} <${client.fromAddress}>`;
  const replyTo = req.replyTo || client.replyToAddress;
  try {
    const response = await fetch(`${apiBase}/emails`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        ...idempotencyKey ? { "Idempotency-Key": idempotencyKey.slice(0, 200) } : {}
      },
      body: JSON.stringify({
        from,
        to: Array.isArray(req.to) ? req.to : [req.to],
        subject: req.subject,
        html: req.html,
        text: req.text,
        ...replyTo ? { reply_to: replyTo } : {}
      }),
      signal: AbortSignal.timeout(2e4)
    });
    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.error(`[mail] Resend ${response.status} ${detail.slice(0, 300)}`);
      return { ok: false, status: response.status, error: "provider_error" };
    }
    const payload = await response.json().catch(() => ({}));
    console.log(`[mail] sent "${req.subject}" to ${Array.isArray(req.to) ? req.to.join(",") : req.to}`);
    return { ok: true, id: payload.id };
  } catch (error) {
    console.error("[mail] send failed:", error instanceof Error ? error.message : error);
    return { ok: false, error: "provider_unavailable" };
  }
}

// netlify/functions/send-email.mts
var json = (status, body) => new Response(JSON.stringify(body), {
  status,
  headers: { "Content-Type": "application/json" }
});
var send_email_default = async (req) => {
  if (req.method !== "POST") {
    return json(405, { ok: false, error: "method_not_allowed" });
  }
  const client = authenticate(req.headers.get("authorization"));
  if (!client) {
    return json(401, { ok: false, error: "unauthorized" });
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return json(400, { ok: false, error: "invalid_json" });
  }
  const parsed = validateRequest(body);
  if (!parsed.ok) {
    return json(400, { ok: false, error: parsed.error });
  }
  const idempotencyKey = req.headers.get("idempotency-key");
  const result = await sendViaResend(client, parsed.value, idempotencyKey);
  if (!result.ok) {
    const status = result.status && result.status >= 400 && result.status < 500 ? 400 : 502;
    return json(status, { ok: false, error: result.error || "provider_error" });
  }
  return json(200, { ok: true, id: result.id });
};
var config = {
  path: "/api/send-email",
  method: "POST"
};
export {
  config,
  send_email_default as default
};
